<html>

<head>
    <title>RNSIT | Page Not Found</title>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway|Amatic+SC|Abril+Fatface:300,400,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://teamrasm.github.io/rnsit/css/404.css">
    <link href="images/logo.png" rel="icon" type="image/png" alt="logo">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#021B38">
    <meta name="RNSIT" content="app-id=myAppStoreID, app-argument=myURL">
    <meta name="description" content="R. N. Shetty Institute of Technology (RNSIT) established in the year 2001, is the brain-child of the Group Chairman, Dr. R. N. Shetty. The Murudeshwar Group of Companies headed by Sri. R. N. Shetty is a leading player in many industries viz construction, manufacturing, hotel, automobile, power & IT services and education. The group has contributed significantly to the field of education. A number of educational institutions are run by the R. N. Shetty Trust, RNSIT being one amongst them. With a continuous desire to provide quality education to the society, the group has established RNSIT, an institution to nourish and produce the best of engineering talents in the country. RNSIT is one of the best and top accredited engineering colleges in Bengaluru.">
    <meta property=”og:title” content=”RNSIT” />
    <meta property=”og:description” content="R. N. Shetty Institute of Technology (RNSIT) established in the year 2001, is the brain-child of the Group Chairman, Dr. R. N. Shetty. The Murudeshwar Group of Companies headed by Sri. R. N. Shetty is a leading player in many industries viz construction, manufacturing, hotel, automobile, power & IT services and education. The group has contributed significantly to the field of education. A number of educational institutions are run by the R. N. Shetty Trust, RNSIT being one amongst them. With a continuous desire to provide quality education to the society, the group has established RNSIT, an institution to nourish and produce the best of engineering talents in the country. RNSIT is one of the best and top accredited engineering colleges in Bengaluru." />
    <meta property=”og:url” content="https://rnsit.ac.in" />
    <meta property=”og:image” content="https://rnsaikya.herokuapp.com/static/img/rnsit.png" />
    <link rel="apple-touch-icon" href="images/logo.png" />
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="RNSIT" content="RNSIT">
    <link rel="icon" sizes="192x192" href="images/logo.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>

<body>
    <div class="container">
        <h3>Page not found</h3>
        <img src="images/404.png" />
        <p>The page you seek doesn't exist or has been shredded.</p>
        <a href="/">Go back home</a>
    </div>

</body>

</html>
